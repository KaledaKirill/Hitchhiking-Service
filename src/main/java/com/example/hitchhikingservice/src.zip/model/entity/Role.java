package com.example.hitchhikingservice.model.entity;

public enum Role {
    USER,
    ADMIN
}
