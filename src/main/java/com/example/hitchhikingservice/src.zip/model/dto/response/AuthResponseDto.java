package com.example.hitchhikingservice.model.dto.response;

public record AuthResponseDto(
        String token
) {}
